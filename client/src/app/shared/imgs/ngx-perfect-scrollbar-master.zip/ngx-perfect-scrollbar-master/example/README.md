# Example app for the ngx-perfect-scrollbar
